# Code Citations

## License: unknown
https://github.com/scarlettrobe/Miami-Kev-Store/tree/cbedb5b5422f5a9c7677a44c6f4e5415b353a00c/react-app/src/components/SignupFormModal/store/order.js

```
const response = await fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(order),
        });

        if (response.ok)
```

